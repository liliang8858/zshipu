
搭建自己的技术博客系列（一）使用 hexo 搭建一个精美的静态博客   
https://www.jianshu.com/p/b835a7a906c1

搭建自己的技术博客系列（二）把 Hexo 博客部署到 GitHub 上   
https://www.jianshu.com/p/5efd8c6eb3e9

本地运行命令   
hexo s

发布命令
hexo c    
hexo g   
hexo d

