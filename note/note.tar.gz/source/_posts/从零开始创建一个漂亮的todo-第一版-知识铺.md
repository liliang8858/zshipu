title: 从零开始创建一个漂亮的todo 第一版- 知识铺
author: 知识铺
date: 2019-11-03 15:43:40
tags:
---
知识铺： 致力于打造轻知识点，持续更新每次的知识点较少，阅读不累。不占太多时间，不停地来唤醒记忆深处的知识点。

css零基础，一步一步实现一个漂亮的todo
一、 vue.js + html
app.vue

![知识铺-pasted-34.png](https:\/\/blog.zshipu.com/note/images/pasted-34.png)
HelloWorld.vue

![知识铺-pasted-35.png](https:\/\/blog.zshipu.com/note/images/pasted-35.png)

![知识铺-pasted-36.png](https:\/\/blog.zshipu.com/note/images/pasted-36.png)


![知识铺-pasted-37.png](https:\/\/blog.zshipu.com/note/images/pasted-37.png)

![知识铺-pasted-38.png](https:\/\/blog.zshipu.com/note/images/pasted-38.png)
![知识铺-pasted-39.png](https:\/\/blog.zshipu.com/note/images/pasted-39.png)
![知识铺-pasted-40.png](https:\/\/blog.zshipu.com/note/images/pasted-40.png)
[目前做到效果](https://zshipu.com/todo/)

![知识铺-pasted-41.png](https:\/\/blog.zshipu.com/note/images/pasted-41.png)
终极目标：

![知识铺-pasted-42.png](https:\/\/blog.zshipu.com/note/images/pasted-42.png)
