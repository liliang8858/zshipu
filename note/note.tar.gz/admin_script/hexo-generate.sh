#!/usr/bin/env sh
cd ..
hexo generate -b

